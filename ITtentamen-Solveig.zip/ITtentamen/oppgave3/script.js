//Se i concole
//Summen av to tall er 7. Differansen mellom det største
//og det minste tallet er 3. Finn tallene.
let likning1 = (x+y=7);
let likning2 = (x-y=3);
likning1 = likning2

//Dårlig gjort å gi matteoppgave
