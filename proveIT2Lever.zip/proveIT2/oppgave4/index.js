//alert("Javascript er lastet");

let far = prompt("Hva er temperaturen i farenheit?");
let cel = (far-32)/1.8;

alert(far + " grader i celsius er " + cel.toFixed(2) + " grader.")
//Viser hvor mange grader et gitt antall grader av farenheit er i celsius.
