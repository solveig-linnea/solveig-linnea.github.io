//alert("JS er lastet");
 let operasjon = prompt("Hvilken regneopereasjon skal utføres? skriv: +, -, * eller /");

 let tall1 = Number(prompt("Skriv inn det første tallet"));
 let tall2 = Number(prompt("Skriv inn the andre tallet"));

 let stykke = tall1 + operasjon + tall2;
 let svar = (stykke);

 alert("Dette er regnestykket: " + stykke + ". Da blir svaret: " + svar)
 //Forstår ikke hvordan man får gjort om operasjonene fra string slik at de kan brukes i en regneoppgave.
